#include "geobaza.h"
#include <stdio.h>
#include <sys/types.h>
#include <stdlib.h>
#include <stdint.h>



int main(int argc, char **argv) {
    GEOBAZA geobaza;
    int i;
    /*
     ** Use either geobaza_open or geobaza_load
     **
     ** Geobaza_open opens geobaza.dat file for reading and on each geobaza_lookup call
     ** reads some data from file.
     ** Use geobaza_open when you need not too many lookups.
     **
     ** Geobaza_load loads all content of geobaza.dat file to RAM and then closes file.
     ** There are no need to access HDD on each lookup.
     ** Warning: it takes more than 40 MB of RAM! Also reading whole file to RAM takes some time,
     ** so, use geobaza_load only when you plan to make many lookups (more than 1000).
     */
    #define TOO_MANY_LOOKUPS

    #ifndef TOO_MANY_LOOKUPS
    if ( geobaza_open(&geobaza, "../geobaza.dat") != 0 ) {
    #else
    if ( geobaza_load(&geobaza, "../geobaza.dat") != 0 ) {
        #endif
        printf("Can't open geobaza.\n");
        exit(-1);
    }

    for ( i=1; i<argc; i++ ) {
        uint32_t ipnum;
        GEOBAZA_PLACE *place;
        printf("Argument #%d: (%s)\n", i, argv[i]);
        if ( geobaza_aton(argv[i], &ipnum) == 0 ) {
            printf("\tparsed as ip address.\n");
            if ( geobaza_lookup(&geobaza, ipnum, &place) == 0 ) {
                GEOBAZA_PLACE *item;
                printf("Lookup ok.\n");
                for ( item = place; item; item = item->parent ) {
                    int i_names;
                    printf("RESULT:\n");
                    printf("\tspecial:%s;\n", item->special);
                    printf("\tid:%s;\n", item->id);
                    printf("\ttype:%s;\n", item->type);
                    printf("\tpopulation:%d;\n", (int)item->population);
                    printf("\tlat,lon:%f,%f;\n", item->lat, item->lon);
                    printf("\tlang:%s;\n", item->language);
                    for ( i_names = 0; item->name_lang[i_names] && (i_names < GEOBAZA_MAX_NAMES); i_names ++ )
                        printf("\t#%d lang:%s; name:%s; official:%s;\n", i_names, item->name_lang[i_names], item->name_common[i_names], item->name_official[i_names]);
                }
                printf("\n\n");
                geobaza_free_result(&place);
            }
        }
    }

    geobaza_close(&geobaza);

    return 0;
}
