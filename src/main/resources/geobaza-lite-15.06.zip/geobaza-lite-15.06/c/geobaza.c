#include "geobaza.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>



int geobaza_open(GEOBAZA *geobaza, char *filename) {
    unsigned char buffer[8];
    int levels_pos;
    memset(geobaza, 0, sizeof(GEOBAZA));

    geobaza->fp = fopen(filename, "rb");
    if ( !geobaza->fp )
        return -1;

    if ( !fread(buffer, 7, 1, geobaza->fp) )
        return -1;

    if ( strncmp(buffer, "GEOBAZA", 7) != 0 )
        return -1;

    if ( !fread(buffer, 2, 1, geobaza->fp) )
        return -1;

    fseek(geobaza->fp, buffer[0]*256+buffer[1], SEEK_CUR);

    for (levels_pos=0; levels_pos<32; levels_pos+=2) {
        if ( !fread(buffer, 1, 1, geobaza->fp) )
            return -1;
        geobaza->levels[levels_pos] = (buffer[0] >> 4) & 0x0f;
        geobaza->levels[levels_pos+1] = buffer[0] & 0x0f;
        if ( geobaza->levels[levels_pos]==0 || geobaza->levels[levels_pos+1]==0 )
            break;
    }
    geobaza->offset = ftell(geobaza->fp);
    return 0;
}



int geobaza_load(GEOBAZA *geobaza, char *filename) {
    if ( geobaza_open(geobaza, filename) != 0 )
        return -1;
    fseek(geobaza->fp, 0, SEEK_END);
    geobaza->memfile_size = ftell(geobaza->fp);
    geobaza->memfile = (unsigned char*)malloc(geobaza->memfile_size*2);
    if ( !geobaza->memfile )
        return -1;
    fseek(geobaza->fp, 0, SEEK_SET);
    if ( fread(geobaza->memfile, geobaza->memfile_size, 1, geobaza->fp) != 1 )
        return -1;
    fclose(geobaza->fp);
    geobaza->fp = NULL;
    return 0;
}



int geobaza_close(GEOBAZA *geobaza) {
    if ( geobaza->fp )
        fclose(geobaza->fp);
    if ( geobaza->memfile )
        free(geobaza->memfile);
    memset(geobaza, 0, sizeof(GEOBAZA));
    return 0;
}



uint32_t htonl(uint32_t a) {
    unsigned char *buffer = (unsigned char*) &a;
    return 0x1000000 * buffer[0] + 0x10000 * buffer[1] + 0x100 * buffer[2] + buffer[3];
}



int geobaza_lookup(GEOBAZA *geobaza, uint32_t ip, GEOBAZA_PLACE **place) {
    int shift;
    size_t offset;
    int l;
    unsigned char buffer[4];

    offset = geobaza->offset;
    shift = 32;
    for ( l = 0;  l < 32; l ++ ) {
        uint32_t index;
        size_t tell;
        shift -= geobaza->levels[l];
        index = (ip>>shift) & ((1<<geobaza->levels[l])-1);
        tell = offset + index * 4;
        if ( geobaza->memfile ) {
            if ( tell + 4 > geobaza->memfile_size )
                return -1;
            offset = htonl(*(uint32_t*)(geobaza->memfile + tell));
        }
        else {
            if ( fseek(geobaza->fp, tell, SEEK_SET) != 0 )
                return -1;
            if ( fread(buffer, 4, 1, geobaza->fp) == 0 )
                return -1;
            offset = htonl(*(uint32_t*)buffer);
        }
        if ( offset & 0x80000000 ) {
            while ( offset ) {
                unsigned short data_length;
                GEOBAZA_PLACE *this_place;
                char *p, *p_name = NULL, *p_official = NULL;
                char *start, *end;
                char *p_hash;

                if ( geobaza->memfile ) {
                    if ( (offset & 0x7fffffff) + 2 > geobaza->memfile_size )
                        return -1;
                    memcpy(buffer, geobaza->memfile + (offset & 0x7fffffff), 2);
                }
                else {
                    if ( fseek(geobaza->fp, offset & 0x7fffffff, SEEK_SET) != 0 )
                        return -1;
                    if ( fread(buffer, 2, 1, geobaza->fp) == 0 )
                        return -1;
                }
                *place = (GEOBAZA_PLACE*)malloc(sizeof(GEOBAZA_PLACE));
                if ( !*place )
                    return -1;
                memset(*place, 0, sizeof(GEOBAZA_PLACE));
                data_length = 0x100 * buffer[0] + buffer[1];
                (*place)->text_buffer = (char*)malloc(data_length + 1);
                if ( !(*place)->text_buffer )
                    return -1;
                (*place)->text_buffer[data_length] = 0;
                if ( geobaza->memfile ) {
                    if ( (offset & 0x7fffffff) + 2 + data_length > geobaza->memfile_size )
                        return -1;
                    memcpy((*place)->text_buffer, geobaza->memfile + (offset & 0x7fffffff) + 2, data_length);
                }
                else {
                    if ( fread((*place)->text_buffer, data_length, 1, geobaza->fp) == 0 )
                        return -1;
                }
                this_place = *place;
                if ( geobaza->memfile ) {
                    if ( (offset & 0x7fffffff) + 2 + data_length + 4 > geobaza->memfile_size )
                        return -1;
                    offset = htonl(*(uint32_t*)(geobaza->memfile + (offset & 0x7fffffff) + 2 + data_length));
                }
                else {
                    if ( fread(buffer, 4, 1, geobaza->fp) == 0 )
                        return -1;
                    offset = htonl(*(uint32_t*)buffer);
                }
                place = &(*place)->parent;

                #define JSON_SPECIAL    "\"special\":\""
                #define JSON_ID     "\"id\":\""
                #define JSON_TYPE   "\"type\":\""
                #define JSON_POPULATION "\"population\":"
                #define JSON_LAT    "\"lat\":"
                #define JSON_LON    "\"lon\":"
                #define JSON_LANGUAGE   "\"lang\":\""
                #define JSON_NAME   "\"name\":{"
                #define JSON_OFFICIAL   "\"name_official\":{"

                if ( p = strstr(this_place->text_buffer, JSON_SPECIAL) )
                    this_place->special = p + strlen(JSON_SPECIAL);

                if ( p = strstr(this_place->text_buffer, JSON_ID) )
                    this_place->id = p + strlen(JSON_ID);

                if ( p = strstr(this_place->text_buffer, JSON_TYPE) )
                    this_place->type = p + strlen(JSON_TYPE);

                if ( p = strstr(this_place->text_buffer, JSON_POPULATION) )
                    this_place->population = atol(p + strlen(JSON_POPULATION));

                if ( p = strstr(this_place->text_buffer, JSON_LAT) )
                    this_place->lat = atof(p + strlen(JSON_LAT));

                if ( p = strstr(this_place->text_buffer, JSON_LON) )
                    this_place->lon = atof(p + strlen(JSON_LON));

                if ( p = strstr(this_place->text_buffer, JSON_LANGUAGE) )
                    this_place->language = p + strlen(JSON_LANGUAGE);

                if ( p = strstr(this_place->text_buffer, JSON_NAME) )
                    p_name = p + strlen(JSON_NAME);

                if ( p = strstr(this_place->text_buffer, JSON_OFFICIAL) )
                    p_official = p + strlen(JSON_OFFICIAL);

                if ( start = this_place->special ) {
                    while ( end = strchr(start, '"') )
                        if ( end[-1] == '\\' )
                            start = end + 1;
                    else {
                        *end = 0;
                        break;
                    }
                }

                if ( start = this_place->id ) {
                    while ( end = strchr(start, '"') )
                        if ( end[-1] == '\\' )
                            start = end + 1;
                    else {
                        *end = 0;
                        break;
                    }
                }
                if ( start = this_place->type ) {
                    while ( end = strchr(start, '"') )
                        if ( end[-1] == '\\' )
                            start = end + 1;
                    else {
                        *end = 0;
                        break;
                    }
                }
                if ( start = this_place->language ) {
                    while ( end = strchr(start, '"') )
                        if ( end[-1] == '\\' )
                            start = end + 1;
                    else {
                        *end = 0;
                        break;
                    }
                }

                p_hash = p_name;
                while ( p_hash ) {
                    char *p_key, *p_val, *p_close;
                    if ( p_key = strchr(p_hash, '"') ) {
                        p_key ++;
                        if ( p_val = strstr(p_key, "\":\"") ) {
                            int i_name;
                            *p_val = 0;
                            p_val += strlen("\":\"");
                            start = p_val;
                            while ( end = strchr(start, '"') )
                                if ( end[-1] == '\\' )
                                    start = end + 1;
                            else {
                                *end = 0;
                                if ( end[1] == ',' )
                                    p_hash = end + 2;
                                else
                                    p_hash = NULL;
                                break;
                            }
                            for ( i_name = 0; i_name < GEOBAZA_MAX_NAMES; i_name++ ) {
                                if ( this_place->name_lang[i_name] == NULL )
                                    this_place->name_lang[i_name] = p_key;
                                if ( strcmp(this_place->name_lang[i_name], p_key) == 0 ) {
                                    this_place->name_common[i_name] = p_val;
                                    break;
                                }
                            }
                        }
                    }
                }

                p_hash = p_official;
                while ( p_hash ) { {
                        char *p_key, *p_val, *p_close;
                        if ( p_key = strchr(p_hash, '"') ) {
                            p_key ++;
                            if ( p_val = strstr(p_key, "\":\"") ) {
                                int i_name;
                                *p_val = 0;
                                p_val += strlen("\":\"");
                                start = p_val;
                                while ( end = strchr(start, '"') )
                                    if ( end[-1] == '\\' )
                                        start = end + 1;
                                else {
                                    *end = 0;
                                    if ( end[1] == ',' )
                                        p_hash = end + 2;
                                    else
                                        p_hash = NULL;
                                    break;
                                }

                                for ( i_name = 0; i_name < GEOBAZA_MAX_NAMES; i_name++ ) {
                                    if ( this_place->name_lang[i_name] == NULL )
                                        this_place->name_lang[i_name] = p_key;
                                    if ( strcmp(this_place->name_lang[i_name], p_key) == 0 ) {
                                        this_place->name_official[i_name] = p_val;
                                        break;
                                    }
                                }
                            }
                        }
                    }
                }
            }
            return 0;
        }
    }
    return -1;
}



int geobaza_free_result(GEOBAZA_PLACE **place) {
    if ( *place ) {
        if ( (*place)->text_buffer )
            free((*place)->text_buffer);
        if ( (*place)->parent )
            geobaza_free_result(&(*place)->parent);
        free(*place);
        *place = NULL;
    }
    return 0;
}



int geobaza_aton(char *text, uint32_t *ip) {
    uint32_t ip_acc = 0;
    int octet = 0;
    int octet_cnt = 0;
    int is_octet = 0;
    char *p;
    for ( p = text; ; p++ ) {
        if ( *p >='0' && *p <= '9' ) {
            octet = octet * 10 + ( *p - '0' );
            if ( octet > 255 )
                return -1;
            if ( is_octet == 0 ) {
                octet_cnt ++;
                is_octet = 1;
            }
            continue;
        }
        if ( *p == '.' ) {
            if ( is_octet != 1 )
                return -1;
            if ( octet_cnt >=4 )
                return -1;
            ip_acc = ip_acc * 256 + octet;
            is_octet = 0;
            octet = 0;
            continue;
        }
        if ( *p == 0 ) {
            if ( is_octet != 1 )
                return -1;
            if ( octet_cnt != 4 )
                return -1;
            *ip = ip_acc * 256 + octet;
            break;
        }
        return -1;
    }
    return 0;
}
