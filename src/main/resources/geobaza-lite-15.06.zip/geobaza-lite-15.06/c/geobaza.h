#ifndef _GEOBAZA_
#define _GEOBAZA_



#include <stdio.h>
#include <sys/types.h>
#include <stdint.h>



#define GEOBAZA_MAX_NAMES   20



typedef struct
{
    FILE *fp;
    size_t offset;
    int levels[32];
    unsigned char *memfile;
    size_t memfile_size;
} GEOBAZA;



typedef struct GEOBAZA_PLACE
{
    char *special;
    char *id;
    char *type;
    long population;
    float lat;
    float lon;
    char *language;
    char *name_lang[GEOBAZA_MAX_NAMES];
    char *name_common[GEOBAZA_MAX_NAMES];
    char *name_official[GEOBAZA_MAX_NAMES];
    char *text_buffer;
    struct GEOBAZA_PLACE *parent;
} GEOBAZA_PLACE;



int geobaza_open(GEOBAZA*, char*);
int geobaza_load(GEOBAZA*, char*);
int geobaza_close(GEOBAZA*);
int geobaza_lookup(GEOBAZA*, uint32_t, GEOBAZA_PLACE**);
int geobaza_free_result(GEOBAZA_PLACE**);
int geobaza_aton(char*, uint32_t*);



#endif
