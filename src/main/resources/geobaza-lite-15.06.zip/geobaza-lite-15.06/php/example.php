<?php


require "Geobaza.php";

$geobaza = new Geobaza("../geobaza.dat");

if ( !$geobaza->is_valid() ) {
    print "Can't load geobaza (".$geobaza->get_error().").<br>\n";
    die();
}

print "== HEADERS ==\n";
print_r($geobaza->get_headers());
print "\n";


if ( isset($argv) ) {
    // This is CLI launch
    $iparr = $argv;
    array_shift($iparr);
    if ( !sizeof($iparr) )
	$iparr = array("127.0.0.1");
}
else {
    // This is WWW launch
    $iparr = explode("\n", @$_REQUEST['ips']);
    if ( !sizeof($iparr) || @$_REQUEST['ips']=='')
	$iparr = array($_SERVER['REMOTE_ADDR']);
    ?>
<html>
<head>
<meta http-equiv="Content-Type" content="text/plain; charset=utf-8">
<title>Geobaza: example</title>
</head>
<body>

<p>Please, put one IP address per line in this textarea:</p>
<form method=get action=<?php echo $_SERVER['SCRIPT_NAME']?>>
<textarea cols=25 rows=5 name=ips><?php echo $_REQUEST['ips']?></textarea>
<br>
<input type=submit value="Test this IP addresses">
</form>
<pre>
<?php
}



foreach ( $iparr as $ip ) {
    $ip = trim($ip);
    if ( !ereg("^[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}$", $ip) )
	continue;

    print "=== $ip ===\n";
    
    $result = $geobaza->lookup($ip);
    
    print "result (JSON): ".json_encode($result)."\n";
    
    if ( @$result['special'] ) {
	print "Special range: $result[special]\n\n";
    }
    else {
	foreach ( $result['items'] as $item ) {
	    print "id: $item[id]\n";
	    print "iso_id: $item[iso_id]\n";
	    print "type: $item[type]\n";
	    print "language: $item[lang]\n";
	    print "geography: lat=$item[lat], lon=$item[lon]\n";
	    print "population: $item[population]\n";
	    if ( isset($item['name']) ) {
		print "common names:\n";
		foreach ( array_keys($item['name']) as $lang) {
		    print "\t$lang: ".$item['name'][$lang]."\n";
		}
	    }
	    if ( isset($item['name_official']) ) {
		print "official names:\n";
		foreach ( array_keys($item['name_official']) as $lang) {
		    print "\t$lang: ".$item['name_official'][$lang]."\n";
		}
	    }
	    print "\n";
	}
    }
    print "\n";
}


if ( !isset($argv) ) {
    ?>
</pre>
</body>
</html>
<?php
}
?>

