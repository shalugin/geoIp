<?php


require "Geobaza.php";

$geobaza = new Geobaza("../geobaza.dat");

if ( !$geobaza->is_valid() ) {
    print "Can't load geobaza.<br>\n";
    die();
}


$s=100000;
for($i=0;$i<$s;$i++) {
    $iparr[]=rand(0,0xff).".".rand(0,0xff).".".rand(0,0xff).".".rand(0,0xff);
}



$time_start = time();
foreach ( $iparr as $ip ) {
    $ip = trim($ip);
    if ( !ereg("^[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}$", $ip) )
	continue;

#    print "=== $ip ===\n";
    
    $result = $geobaza->lookup($ip);
    
/*
    print "result (JSON): ".json_encode($result)."\n";
    
    if ( $result['special'] ) {
	print "Special range: $result[special]\n\n";
    }
    else {
	foreach ( $result['items'] as $item ) {
	    print "id: $item[id]\n";
	    print "type: $item[type]\n";
	    print "language: $item[lang]\n";
	    print "geography: lat=$item[lat], lon=$item[lon]\n";
	    print "population: $item[population]\n";
	    print "common names:\n";
	    foreach ( array_keys($item['name']) as $lang) {
		print "\t$lang: ".$item['name'][$lang]."\n";
	    }
	    if ( isset($item['name_official']) ) {
		print "official names:\n";
		foreach ( array_keys($item['name_official']) as $lang) {
		    print "\t$lang: ".$item['name_official'][$lang]."\n";
		}
	    }
	    print "\n";
	}
    }
    print "\n";
*/
}
$time_stop = time();

print "\n\n".sizeof($iparr)." in ".($time_stop-$time_start)." seconds\n";

?>

