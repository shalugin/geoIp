#!/usr/bin/perl

use Geobaza;
use strict;


my $geobaza = new Geobaza('dbfile'=>"../geobaza.dat") || die;
my $header = $geobaza->get_headers();
print "=== HEADERS ===\n";
foreach my $key ( keys %{$header} ) {
    print "$key => $$header{$key}\n";
}


die "USAGE: $0 ip1 [ip2 ...]" unless ( @ARGV );
print "";
foreach my $ip ( @ARGV ) {
    print "=== $ip ===\n";
    
    my $res = $geobaza->lookup($ip);

#    print "result (JSON): ".to_json($res)."\n";
    if ( ref $res eq 'HASH' ) {
	if ( exists $$res{'special'} ) {
	    print "Special range: $$res{special}\n";
	}
	if ( ref $$res{'items'} eq 'ARRAY' ) {
	    foreach my $item ( @{$$res{'items'}} ) {
		print "id: $$item{id}\n";
		print "type: $$item{type}\n";
		print "language: $$item{lang}\n";
		print "geography: lat=$$item{lat}, lon=$$item{lon}\n";
		print "population: $$item{population}\n";
		print "common names:\n";
		foreach my $lang ( keys %{$$item{'name'}} ) {
		    print "\t$lang: $$item{name}{$lang}\n";
		}
		if ( exists $$item{'name_official'} ) {
		print "official names:\n";
		    foreach my $lang ( keys %{$$item{'name_official'}} ) {
			print "\t$lang: $$item{name_official}{$lang}\n";
		    }
		}
		print "\n";
	    }
	}
    }
    print "\n";
}
