#!/usr/bin/perl

use Geobaza;
use strict;


my $geobaza = new Geobaza('dbfile'=>"../geobaza.dat") || die;
my $header = $geobaza->get_headers();
print "=== HEADERS ===\n";
foreach my $key ( keys %{$header} ) {
    print "$key => $$header{$key}\n";
}


my $i;
my $count = 100000;
my $time_start = time();
for ( $i=0; $i<$count; $i++ ) {
    my $ip = int(rand(255)).'.'.int(rand(255)).'.'.int(rand(255)).'.'.int(rand(255));
    my $res = $geobaza->lookup($ip);
}

my $time_stop = time();

print "Processed $count requests in ".($time_stop-$time_start)." seconds.\n";
