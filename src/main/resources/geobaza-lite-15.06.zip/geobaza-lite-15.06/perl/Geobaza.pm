#!/usr/bin/perl

# 
# 
# GEOBAZA module
# 
# 

=head1 NAME

GEOBAZA - Модуль для связи программ на языке PERL с базой Geobaza

=head1 SYNOPSYS

use Geobaza;
my $geobaza = new Geobaza('dbfile'=>"geobaza.dat") || die;
my $res = $geobaza->lookup($ip);
foreach my $item ( @{$res} ) {
	print "$item\n";
}

=head1 DESCRIPTION

Модуль предоставляет объект Geobaza.

В конструкторе должен передаваться параметр 'dbfile', указывающий на расположение файла с базой Geobaza. В случае
отсутствия возможности открыть указанный файл конструктор возвращает значение undef.

Объкт Geobaza обладает методом lookup($ip). Метод возвращает хэш со следующими, не всегда обязательными, ключами:

'error' :	Если данный ключ присутствует, вызов завершился ошибкой. Возможны следующие значения ошибок
		$Geobaza::E_INVALID_IP - аргумент не является ipv4-адресом в формате aaa.bbb.ccc.ddd
		$Geobaza::E_NO_DATAFILE - файл базы данных не может быть открыт
		$Geobaza::E_INVALID_SIGNATURE - файл не является базой данных Geobaza
		$Geobaza::E_INCOMPATIBLE_DATAFILE - файл базы данных не совместимой версии
		$Geobaza::E_INVALID_POSITION - неверная позиция в файле базы данных, возможно, файл поврежден

'special' :	Если данный ключ присутствует, то искомый адрес относится к одному из зарезервированных диапазонов,
		например, 10.0.0.0/8, 192.168.0.0/16 и так далее. Является скаляром.

'items' : 	В случае, если адрес не является зарезервированным, содержит ссылку на список как минимум из одного элемента.
		Каждый элемент списка является описанием географического места. Первый - наиболее точно указывает на место,
		обычно это описание города. Далее может идти описание области, штата, земли. Последний элемент - обычно страна.
		Максимальное количество элементов не регламентировано. Минимальное количество элементов: 1, в таком случае это
		страна.
		
		Каждый элемент является ссылкой на список из 7 элементов. Описание элементов:
		[0] - тип географической единицы. Содержит один символ:
			'c' - страна
			'r' - область/штат/провинция
			't' - город
			'd' - район города
			's' - улица;
		[1] - название на национальном языке страны;
		[2] - название на английском языке;
		[3] - название на русском языке;
		[4] - географическая широта в градусах от -90 до 90. Положительные значения
		соответствуют северному полушарию, отрицательные - южному.
		[5] - географическая долгота в градусах от -180 до 180. Положительные
		значения соответствуют восточному полушарию, отрицательные - западному.
		[6] - краткий двух- или трехбуквенный код страны или штата.
		
		Ключи 'special' и 'items' взаимно исключают друг друга.

'line' :	В случае, если присутствует ключ 'special' или 'items', содержит скалярное описание адреса.


=cut

package Geobaza;

use strict;


our ($VERSION, $E_INVALID_IP, $E_NO_DATAFILE, $E_INVALID_SIGNATURE, $E_INCOMPATIBLE_DATAFILE, $E_INVALID_POSITION);


BEGIN {

    *E_INVALID_IP =\ 'invalid ip';
    *E_NO_DATAFILE =\ 'no datafile';
    *E_INVALID_SIGNATURE =\ 'invalid signature';
    *E_INCOMPATIBLE_DATAFILE =\ 'incompatible datafile version';
    *E_INVALID_POSITION =\ 'invalid datafile position';
}


sub new {
    my($class, %init) = @_;
    my $self = {};
    bless $self;

    if ( defined $init{'dbfile'} ) {
	$$self{'dbfile'} = $init{'dbfile'};
    }
    else {
	$$self{'dbfile'} = "geobaza.dat";
    }
    return undef unless -r $$self{'dbfile'};
    return undef unless -f $$self{'dbfile'};
    
    open($$self{'FILE'}, $$self{'dbfile'}) || return undef;

    use bytes;

    my $buffer;
    read($$self{'FILE'}, $buffer, 7) || return undef;
    return undef unless $buffer eq 'GEOBAZA';

    read($$self{'FILE'}, $buffer, 2) || return undef;
    my $header_length = unpack('n', $buffer);
    
    read($$self{'FILE'}, $buffer, $header_length) || return undef;
    $$self{'header'} = &from_json1($buffer);
    
    $$self{'levels'} = [];
    for (;;) {
	read($$self{'FILE'}, $buffer, 1) || return undef;
	my $byte = unpack('C', $buffer);
	my $hi = ($byte>>4) & 0x0f;
	my $lo = $byte & 0x0f;
	push @{$$self{'levels'}}, $hi;
	last if $hi == 0;
	push @{$$self{'levels'}}, $lo;
	last if $lo == 0;
    }
    
    no bytes;

    $$self{'offset'} = tell($$self{'FILE'});
    
    return $self;
}



sub DESTROY() {
    my $self = shift;
    close($$self{'FILE'});
}



sub get_headers() {
    my ($self) = @_;
    my %header_copy = %{$$self{'header'}};
    return \%header_copy;
}



sub lookup {
    my ($self, $ip) = @_;
    my @result = ();

    # Проверка формата аргумента $ip.
    $$self{'error'} = $E_INVALID_IP;

    return ( 'error' => $E_INVALID_IP ) unless $ip =~ /^(\d{1,3})\.(\d{1,3})\.(\d{1,3})\.(\d{1,3})$/;
    return ( 'error' => $E_INVALID_IP ) if $1>255 || $2>255 || $3>255 || $4>255;

    my ( $ipint, $data, $shift, $offset, $info );

    # Преобразование адреса в формат 32-битного целого
    $ipint = ($1<<24) + ($2<<16) + ($3<<8) + $4;

    use bytes;
    
    seek($$self{'FILE'}, $$self{'offset'}, 0) || return { 'error' => $E_INVALID_POSITION };
    
    $shift = 32;
    $offset = $$self{'offset'};
    
    for(my $l=0; $l<@{$$self{'levels'}}; $l++) {
	$shift -= $$self{'levels'}[$l];
	my $index = (($ipint>>$shift)) & ((1<<$$self{'levels'}[$l])-1);
	my $tell = $offset + $index*4;
	seek($$self{'FILE'}, $tell, 0) || return undef;
	read($$self{'FILE'}, $data, 4) || return undef;

	$offset = unpack('N',$data);
	if ( $offset & 0x80000000 ) {
	    while ( $offset ) {
		$tell = $offset & 0x7fffffff;
		seek($$self{'FILE'}, $tell, 0) || return undef;
		read($$self{'FILE'}, $data, 2) || return undef;
		my $length = unpack('n', $data);
		read($$self{'FILE'}, $data, $length) || return undef;
		my $unpacked_data = &from_json1($data);
		if ( exists $$unpacked_data{'special'} ) {
		    return $unpacked_data;
		}
		
		push @result, $unpacked_data;
		read($$self{'FILE'}, $data, 4) || return undef;
		$offset = unpack('N', $data);
	    }
	    last;
	}
    }

    no bytes;

    return { 'items'=> [ @result ] };
}



sub from_json1($) {
    my $text = shift;
    $text =~ s/":/"=>/g; 
    $text =~ s/"=>null/"=>undef/g;
    my $var;
    my $code = "\$var=".$text.";";
    eval($code);
    return $var;
}

1;


__END__
