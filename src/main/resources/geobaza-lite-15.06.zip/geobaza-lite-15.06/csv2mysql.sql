CREATE TABLE geobaza_ranges (
    start CHAR(15) NOT NULL,
    end CHAR(15) NOT NULL,
    ip_int INT UNSIGNED NOT NULL,
    length INT UNSIGNED NOT NULL,
    tld CHAR(4), id INT NOT NULL
);

LOAD DATA LOCAL INFILE '/tmp/geobaza.ranges.csv'
    INTO TABLE geobaza_ranges
    CHARACTER SET utf8
    FIELDS TERMINATED BY ', '
    ENCLOSED BY '"'
    (start, end, ip_int, length, tld, id);

DELETE FROM geobaza_ranges WHERE start = 'ip_start';

CREATE TABLE geobaza_objects (
    id INT NOT NULL UNIQUE,
    parent_id INT NOT NULL,
    type VARCHAR(100),
    name_en VARCHAR(255),
    name_ru VARCHAR(255),
    lat FLOAT,
    lon FLOAT
) CHARSET utf8;

load data local infile '/tmp/geobaza.objects.csv'
    INTO TABLE geobaza_objects
    CHARACTER SET utf8
    FIELDS TERMINATED BY ', '
    ENCLOSED BY '"'
    (id, parent_id, type, name_en, name_ru, lat, lon);

DELETE FROM geobaza_objects WHERE id = 0;
